package bucles_for;

public class Extra_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
	}

}
