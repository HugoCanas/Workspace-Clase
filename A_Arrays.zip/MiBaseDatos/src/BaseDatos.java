import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BaseDatos {
	private Connection cn;
	private String driver, cadenaConexion;

	public BaseDatos() {
		cadenaConexion="jdbc:mysql://localhost:3306/socios";
		driver="com.mysql.jdbc.Driver";
		try {
			cn=DriverManager.getConnection(cadenaConexion, "root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}


	//GETTERS/SETTERS

	public Connection getCn() {
		return cn;
	}

	public void setCn(Connection cn) {
		this.cn = cn;
	}

	//FUNCIONES 
	//OBTENER DATOS (RESULTADO DE SELECT)
	public ResultSet obtenerTodos() { //DEVUELVE TODOS LOS DATOS DE TODOS LOS SOCIOS
		String sentencia;
		PreparedStatement sqlSent;
		ResultSet rs;
		sentencia="SELECT * FROM socios";
		try {
			sqlSent=cn.prepareStatement(sentencia, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs = sqlSent.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public ResultSet obtenerDatos(String sentencia) { //DEVUELVE TODOS LOS DATOS DE TODOS LOS SOCIOS
		PreparedStatement sqlSent;
		ResultSet rs;
		try {
			sqlSent=cn.prepareStatement(sentencia, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			rs=sqlSent.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public int insertarSocio(String nombre,String direccion,String telefono ) {
		//DEVUELVE EL NUMERO DE FILAS INSERTADAS
		String sent;
		//PREPARAR LA SENTENCIA 
		sent = "INSERT INTO socios (nombre,direccion,telefono) VALUES (?,?,?)";
		PreparedStatement sentencia;

		try {
			sentencia=cn.prepareStatement(sent);
			sentencia.setString(1, nombre);
			sentencia.setString(2, direccion);
			sentencia.setString(3, telefono);
			int cont= sentencia.executeUpdate();
			return cont;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//SE EJECUTA CON EXECUTEUPDATE
		return 0;
	}

	public void actualizarSocio(int modo, int numSocio, String nombre, String direccion, String telefono) {
		
		
		
	}
	
	public void actualizarSocio(String sentencia) {
		
	}

	public int insertarSocio(Socio socio) {
		String sent;
		//PREPARAR LA SENTENCIA
		sent = "INSERT INTO socios (nombre,direccion,telefono) VALUES (?,?,?)";
		PreparedStatement sentencia;

		try {
			sentencia=cn.prepareStatement(sent);
			sentencia.setString(1, socio.getNombre());
			sentencia.setString(2, socio.getDireccion());
			sentencia.setString(3, socio.getTelefono());
			return sentencia.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//SE EJECUTA CON EXECUTEUPDATE
		return 0;
	}




	//INSERTAR DATOS EN LA BD


}
