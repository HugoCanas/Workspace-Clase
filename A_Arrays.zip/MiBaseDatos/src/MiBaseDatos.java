import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MiBaseDatos extends JFrame {

	private static final long serialVersionUID = 1L;
	private static final int NAVEGACION=0;
	private static final int EDICION=1;
	private static final int ADD=2;
	private JPanel contentPane;
	private JButton btnEdit;
	private JButton btnSalir;
	private JTextField textSocio;
	private JTextField textNombre;
	private JTextField textDireccion;
	private JTextField textTelefono;
	private JTextField txtRegistro;
	private JButton btnAdd;
	private JButton btnDelete;
	private JButton btnCancel;

	private BaseDatos baseDatos;
	private ResultSet rs;
	private int regActual;
	private JButton btnPrim;
	private JButton btnAnt;
	private JButton btnSig;
	private JButton btnUlt;
	private JButton btnOk;
	private JPanel panel;
	private int modo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MiBaseDatos frame = new MiBaseDatos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public MiBaseDatos() throws SQLException {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 861, 527);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		btnEdit = new JButton("Editar");
		btnEdit.setBounds(489, 111, 89, 23);
		contentPane.add(btnEdit);

		btnAdd = new JButton("Añadir");
		btnAdd.setBounds(489, 163, 89, 23);
		contentPane.add(btnAdd);

		btnDelete = new JButton("Eliminar");
		btnDelete.setBounds(489, 242, 89, 23);
		contentPane.add(btnDelete);

		btnSalir = new JButton("Salir");
		btnSalir.setBounds(662, 436, 89, 23);
		contentPane.add(btnSalir);

		JLabel lblNewLabel = new JLabel("Nº Socio:");
		lblNewLabel.setBounds(71, 115, 57, 14);
		contentPane.add(lblNewLabel);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(71, 167, 57, 14);
		contentPane.add(lblNombre);

		JLabel lblDireccion = new JLabel("Direccion:");
		lblDireccion.setBounds(71, 228, 57, 14);
		contentPane.add(lblDireccion);

		JLabel lblTelefono = new JLabel("Telefono:");
		lblTelefono.setBounds(71, 301, 57, 14);
		contentPane.add(lblTelefono);

		textSocio = new JTextField();
		textSocio.setBounds(160, 112, 86, 20);
		contentPane.add(textSocio);
		textSocio.setColumns(10);

		textNombre = new JTextField();
		textNombre.setColumns(10);
		textNombre.setBounds(160, 164, 153, 20);
		contentPane.add(textNombre);

		textDireccion = new JTextField();
		textDireccion.setColumns(10);
		textDireccion.setBounds(160, 225, 235, 20);
		contentPane.add(textDireccion);

		textTelefono = new JTextField();
		textTelefono.setColumns(10);
		textTelefono.setBounds(160, 298, 115, 20);
		contentPane.add(textTelefono);

		btnCancel = new JButton("Cancel");
		btnCancel.setBounds(732, 141, 89, 23);
		contentPane.add(btnCancel);

		JLabel lblNewLabel_1 = new JLabel("SOCIOS DE ALMI");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(225, 11, 332, 51);
		contentPane.add(lblNewLabel_1);

		textSocio.setEnabled(false);

		panel = new JPanel();
		panel.setBounds(52, 372, 477, 51);
		contentPane.add(panel);
		panel.setLayout(null);

		btnPrim = new JButton("<<");
		btnPrim.setBounds(30, 11, 77, 23);
		panel.add(btnPrim);

		btnAnt = new JButton("<");
		btnAnt.setBounds(117, 11, 48, 23);
		panel.add(btnAnt);

		btnSig = new JButton(">");
		btnSig.setBounds(287, 11, 48, 23);
		panel.add(btnSig);

		btnUlt = new JButton(">>");
		btnUlt.setBounds(356, 11, 89, 23);
		panel.add(btnUlt);

		txtRegistro = new JTextField();
		txtRegistro.setBounds(175, 12, 86, 20);
		panel.add(txtRegistro);
		txtRegistro.setColumns(10);

		btnOk = new JButton("OK");
		btnOk.setBounds(610, 141, 89, 23);
		contentPane.add(btnOk);
		registrarEventos();

		baseDatos=new BaseDatos(); //YA TENEMOS CONEXION CON LA BASE DE DATOS (CONSTRUCTOR EJECUTADO)
		if(baseDatos.getCn()==null) {
			System.exit(1);
		}

		rs=baseDatos.obtenerTodos();
		modo=NAVEGACION;
		if(rs.first()) { //rs=array bidimensional
			regActual=1;
			cargarDatos();
		}

	}//FIN DEL CONSTRUCTOR

	private void registrarEventos() {
		btnEdit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				modoEdicion(true); //NO SE PORQUE EL DE AÑADIR Y ELIMINAR LOS SIGO TENIENDO ACTIVADOS NO SE PORQUE 
				modo=EDICION;
				textNombre.requestFocus();
				textNombre.selectAll();
			}
		});
		
		btnAdd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				modoEdicion(true);
				modo=ADD;
				textSocio.setText("");
				textNombre.setText("");
				textDireccion.setText("");
				textTelefono.setText("");
				txtRegistro.setText("");
				textNombre.requestFocus();
			}
		});
		
		
		btnSig.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//AVANZAR AL SIGUIENTE
				try {
					if(rs.next()) {
						regActual++;
						cargarDatos();
					}
					if(rs.isAfterLast()) { //el cursor se pone despues del ultimo y hay que ponerlo en el ultimo
						rs.previous();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		btnAnt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if(rs.previous()) {
						regActual--;
						cargarDatos();
					}
					if(rs.isBeforeFirst()) {
						rs.next();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});


		btnPrim.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if(rs.first()) {
						regActual = 1;
						cargarDatos();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		btnUlt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					while (!rs.isLast()) {
						regActual++;
						rs.next();
					}
					cargarDatos();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		txtRegistro.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int num,numReg;
				ResultSet rsAux;
				//COGER EL NUMERO ESCRITO (CONTROLAR ERROR SI NO ES NUMERO)
				try {
					num=Integer.parseInt(txtRegistro.getText().trim());
					//COMPROBAR QUE EXISTE ESE NUMERO DE REGISTROS E IR A ESA POSICION 
					rsAux=baseDatos.obtenerDatos("SELECT COUNT(*) FROM SOCIOS");
					rsAux.first();
					numReg=rsAux.getInt(1);

					if(num>0 && num<=numReg) {
						rs.absolute(num);
						regActual=num;
						cargarDatos();
					}else {
						cargarDatos();
					}
				}catch(NumberFormatException | SQLException ex) {
					try {
						cargarDatos();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					txtRegistro.selectAll();
				}

			}
		});

	}//FIN DE REGISTRAR EVENTOS

	public void cargarDatos() throws SQLException{
		//CARGA LOS DATOS DE REGISTRO ACTUAL EN LOS JTextField DEL JFrame
		textSocio.setText(rs.getInt("numSocio")+"");
		textNombre.setText(rs.getString("nombre"));
		textDireccion.setText(rs.getString("direccion"));
		textTelefono.setText(rs.getString("telefono"));
		txtRegistro.setText("Reg "+ regActual);
	}

	public void modoEdicion(boolean modo) {
		//SI RECIBE TRUE 
		//PONE EDITABLE A TRUE: JTextField de Datos (excepto idSocio)
		//PONE ENABLED A TRUE: JButtons ok y cancelar 
		//PONE ENABLED A FALSE: JButtons Editar, Añadir y Eliminar
		//CONTROLES DE NAVEGACION: Enabled a FALSE
		
		//SI RECIBE FALSE: 
		//TODO LO ANTERIOR ALREVES
		
		//PISTA: NO LLEVA IF Y ELSE
		
		textNombre.setEditable(modo);
		textDireccion.setEditable(modo);
		textTelefono.setEditable(modo);
		btnOk.setEnabled(modo);
		btnCancel.setEnabled(modo);
		btnEdit.setEnabled(!modo);    // Cambiado: !modo
		btnAdd.setEnabled(!modo);     // Cambiado: !modo
		btnDelete.setEnabled(!modo);
		for(Component comp : panel.getComponents()) {
			comp.setEnabled(!modo);
		}

		/*for(Component componentes : contentPane.getComponents()) {
			componentes.setEnabled(!modo);
			if(componentes.equals(btnPrim) || componentes.equals(btnUlt) || componentes.equals(btnAnt) || componentes.equals(btnSig) || 
			   componentes.equals(btnAdd) || componentes.equals(btnEdit) || componentes.equals(btnDelete)) {
				this.
			}
		}*/
	}
}
